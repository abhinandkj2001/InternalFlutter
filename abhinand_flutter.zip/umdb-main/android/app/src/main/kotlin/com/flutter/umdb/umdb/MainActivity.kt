package com.flutter.umdb.umdb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
